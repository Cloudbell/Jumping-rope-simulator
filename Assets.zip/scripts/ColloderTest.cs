using UnityEngine;
using System.Collections;

public class ColloderTest : MonoBehaviour
{
    public int num = 0;
    void OnCollisionEnter2D(Collision2D coll)
    {
        Debug.Log("-------��ʼ��ײ------------");
        Debug.Log(coll.gameObject.name);
    }

    void OnCollisionStay2D(Collision2D coll)
    {
        Debug.Log("------������ײ-------------");
        Debug.Log(coll.gameObject.name);
    }

    void OnCollisionExit2D(Collision2D coll)
    {
        num=num+1;
        Debug.Log("------������ײ-------------");
        Debug.Log(coll.gameObject.name);
        Debug.Log(num);
    }
}

