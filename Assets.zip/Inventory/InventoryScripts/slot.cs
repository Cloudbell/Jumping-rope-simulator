using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class slot : MonoBehaviour
{
    public Item slotItem;
    public Image slotImage;
    public Text slotNum;
}
