using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryManager : MonoBehaviour
{
    static InventoryManager instance;

    public Inventory MyBag;
    public GameObject slotGrid;
    public slot slotPrefab;
    public Text itemInformation;
    /*void Awake()
    {
        if (instance != null)
            Destory(this);
        instance = this;
    }*/
    public static void CreateNewItem(Item item)
    {
        slot newItem = Instantiate(instance.slotPrefab, instance.slotGrid.transform.position, Quaternion.identity);
        newItem.gameObject.transform.SetParent(instance.slotGrid.transform);
        newItem.slotItem = item;
        newItem.slotImage.sprite = item.itemImage;
        newItem.slotNum.text = item.itemHeld.ToString();
    }
}
