using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainUIcontroller : MonoBehaviour
{
    /*private static MainUIcontroller _instance;

    public static MainUIcontroller Instance
    {
        get
        {
            return _instance
        }
    }

    void Awake()
    {
        _instance = this;
    }

    public int score = 0;
    public Text scoreText;
    public Text lengthText;

    public void UpdateUI(int s=1)
    {
        scoreText.text = +score;
    }
    */
}
